class HomesController < ApplicationController
  def top
  end

end
