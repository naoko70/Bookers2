# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = 'cc96371b6f0e2995ae70a46640fd11eed5dc3f329881b7a33b6d61cd0b9c1353445ec9f08ffb67784594c83e3b0ca7b904663121b953edfa964e7dd144d4bf73'
Refile.secret_key = 'afb337b815eaacc6a9f5184cd1d262a3cecab25b6ac5a86ae495785672bd822a3763e8cf0287ecd7d83c94425477c455f00ed961fee0a69f5bcdd8142e4d2e63'